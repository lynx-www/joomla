<?php
class TestHelper
{
    /**
     *
     * @param array $params Объект, содержащий параметры модуля
     *
     * @access public
     */    
   public static function set()
    {
        return ; 
    }
} 