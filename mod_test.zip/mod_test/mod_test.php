<?php 
defined('_JEXEC') or die;
require_once dirname(__FILE__) . '/helper.php'; 
$hello = TestHelper::set();
require JModuleHelper::getLayoutPath('mod_test'); 

?>