<?php 
echo $hello; 
echo "Hello";
?>